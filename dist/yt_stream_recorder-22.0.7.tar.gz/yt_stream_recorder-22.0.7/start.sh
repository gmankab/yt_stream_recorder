#!/bin/bash

python yt_stream_recorder
