# yt stream recorder

tool for recording youtube streams

## license

[gnu gpl 3](https://gnu.org/licenses/gpl-3.0.en.html)
