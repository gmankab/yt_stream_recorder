#!/bin/python

import yt_stream_recorder.main
